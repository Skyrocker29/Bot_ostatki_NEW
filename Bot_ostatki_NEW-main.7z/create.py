from aiogram import Bot
from aiogram.dispatcher import Dispatcher
from aiogram.contrib.fsm_storage.memory import MemoryStorage
import os

storage = MemoryStorage()

bot = Bot(token=('5444335354:AAGSTeCd4r_Z4KQNQWt68lcAVE1JCR0XQi0'))
dp = Dispatcher(bot, storage=storage)