from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

bank_list = [
    'КПК "Содействие"',
    'КПК "Фин Ит"',
    'ПК "Контур"',
    'ООО "АльфаСитиФинанс"',
    'ООО "Финконсалтинг"',
    'ООО "Единый центр приема платежей"',
    'СЛК "Развитие"',
    'ЛК "Развитие"',
    'Развитие СК',
    'ИП Щецов',
    'БФ "Аллея Победителей"']

b1 = KeyboardButton(bank_list[0])
b2 = KeyboardButton(bank_list[1])
b3 = KeyboardButton(bank_list[2])
b4 = KeyboardButton(bank_list[3])
b5 = KeyboardButton(bank_list[4])
b6 = KeyboardButton(bank_list[5])
b7 = KeyboardButton(bank_list[6])
b8 = KeyboardButton(bank_list[7])
b9 = KeyboardButton(bank_list[8])
b10 = KeyboardButton(bank_list[9])
b11 = KeyboardButton(bank_list[10])

kb = ReplyKeyboardMarkup(resize_keyboard=True)
kb.add(b1).add(b2).add(b3).add(b4).add(b5).add(b6).add(b7).add(b8).add(b9).add(b10).add(b11).row('Отмена', 'Сохранить')

kb_undo = ReplyKeyboardMarkup(resize_keyboard=True)
kb_undo.add('Отмена')